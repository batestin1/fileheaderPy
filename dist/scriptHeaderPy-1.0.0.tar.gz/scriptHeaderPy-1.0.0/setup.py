from setuptools import setup

setup(
    name = 'scriptHeaderPy',
    version = '1.0.0',
    author = 'Maycon Cypriano Batestin',
    author_email = 'mayconcipriano@gmail.com',
    packages = ['scriptHeaderPy'],
    description = 'A way to create script python with beatiful header',
    long_description = 'file: README.md',
    url = 'https://github.com/batestin1/',
    project_urls = {
        'Código fonte': 'https://github.com/batestin1/',
        'Download': 'https://github.com/batestin1/'
    },
    keywords = 'A way to create script python with beatiful header',
    classifiers = [


    ]
)