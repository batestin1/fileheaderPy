<h1 align="center">
<img src="https://img.shields.io/static/v1?label=fileheaderPy%20POR&message=MAYCON%20BATESTIN&color=7159c1&style=flat-square&logo=ghost"/>


<h3> <p align="center">fileheaderPy </p> </h3>
<h3> <p align="center"> ================= </p> </h3>

>> <h3> Resume </h3>

<p> This library allows you to create one, or several files with the python extension already included, a wonderful header to start your projects.</p>

>> <h3> How Works </h3>

<p> install </p>

```
pip install fileheaderPy

```
<p> on script </p>

```
from fileheaderPy import *

fileheaderPy("hello world")


```
<p> out </p>
```
the hello_world.py was built successfully!
the hello_world.py is locate here: C:\Users\Bates\Documents\Repositorios\PYHEADER\hello_world.py

```

<p> After invoking the function, just follow the instructions that will be asked </p>

>> <h3> Out </h3>
```
                   
                   
                        #********************************************************************************#
                        #                                                                                #
                        #                                  нεℓℓσ,вαтεs!                                  #
                        #                                                                                #
                        #   filename: hello_world.py                                                     #
                        #   created: 2022-03-08                                                          #
                        #   system: Windows                                                              #
                        #   version: 64bit                                                               #
                        #                                       by: Bates <https://github.com/batestin1> #
                        #********************************************************************************#
                        #                           import your librarys below                           #
                        #********************************************************************************#


                    
```